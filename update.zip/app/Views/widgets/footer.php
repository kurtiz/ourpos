<footer class="footer">
    <div class="w-100 clearfix">
        <span class="text-center text-sm-left d-md-inline-block">
            Copyright © <?=date("Y")?>
            <a href="javascript:void(0)" class="text-blue" target="_blank">Our Technologies</a>
            All Rights Reserved.
        </span>
        <span class="float-none float-sm-right mt-1 mt-sm-0 text-center">
            Developed with <i class="fa fa-heart text-danger"></i> by
            <a href="https://aaron.ourtechnologies.org/" class="text-green" target="_blank">
                Papilio Technologies
            </a>
        </span>
    </div>
</footer>
<script src="<?= base_url(); ?>/public/checkSW.js"></script>
<script>

//   setTimeout(()=>{
//       console.clear()
//       console.warn("Do not copy / paste any code here..\n" +
//           "If you temper with any code here, it might affect the performance of" +
//           " the software which might end up malfunctioning.\n" +
//           "You might end up exposing your data hence it can be stolen." +
//           " We are not liable for any malfunctions or data loss if so happens")
//   },1500)
//
// setInterval(()=>{
//     console.clear()
//     console.warn("Do not copy / paste any code here..\n" +
//         "If you temper with any code here, it might affect the performance of" +
//         " the software which might end up malfunctioning.\n" +
//         "You might end up exposing your data hence it can be stolen." +
//         " We are not liable for any malfunctions or data loss if so happens")
// },25000)

</script>