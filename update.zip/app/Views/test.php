<?php
//$x = "hjsakdaljda;sda";
////$count = count($x);
////for ($i = $count; $i > ($count - 4); $i-- ){
////    echo $x[$i];
////}
//print_r(count_chars($x));
//helper(["inflector","text", "date"]);
//echo counted(2, "dog");
//echo highlight_code("joh is good");


//echo password_hash("dg1717&",PASSWORD_DEFAULT);


//print_r($quantity);
//echo "<br>";
//echo $amount;


//echo date('h:i A', strtotime(date("h:i")));

//echo "$barcode0<br>$barcode1";

//$x = 14;
//$x==14? printf(9):$d=8;
//echo $d;


//print_r($data);
//$p=0;
//foreach ($data as $key => $x){
//    print_r($x);
//    echo "<br>";
//    print_r($key);
//    echo "<br>";
//    $p += (float)$x["amount"];
//}
//echo $p;

//echo hash("md5", hash("md5","codingfreaks123") . hash("md4","codingfreaks123"));
?>
<!--!DOCTYPE-->
<!--<html>-->
<!--<body>-->
<!--<form method="post">-->
<!--    <input type="text" name="name" value="aaron"/>-->
<!--    <input type="text" name="age" value="65"/>-->
<!--    <input type="text" name="class" value="form 2"/>-->
<!--    <input type="submit" name="submit"/>-->
<!--</form>-->
<!--</body>-->
<!--</html>-->

<!doctype html>
<html>
<head>Test QR Code</head>
<body>
<div id="brcode>"></div>
</body>
<script src="<?=base_url()?>/public/">
</html>